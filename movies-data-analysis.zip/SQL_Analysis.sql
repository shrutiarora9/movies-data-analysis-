-- Top 5 highest revenue movies
SELECT Title, RevenueMillions
FROM Movies
ORDER BY RevenueMillions DESC
LIMIT 5;

-- Average rating by genre
SELECT Genre, ROUND(AVG(Rating),2) AS Avg_Rating
FROM Movies
GROUP BY Genre
ORDER BY Avg_Rating DESC;

-- Revenue by year
SELECT ReleaseYear, SUM(RevenueMillions) AS Total_Revenue
FROM Movies
GROUP BY ReleaseYear
ORDER BY ReleaseYear;

-- Movies with ROI > 3x
SELECT Title, BudgetMillions, RevenueMillions, 
       ROUND(RevenueMillions/BudgetMillions,2) AS ROI
FROM Movies
WHERE RevenueMillions/BudgetMillions > 3
ORDER BY ROI DESC;
