# 🎬 Movie Ratings & Revenue Analysis

## 📌 Overview
This project analyzes a synthetic dataset of movies to explore:
- Revenue patterns by genre
- Relationship between rating, budget, and revenue
- High ROI (return on investment) movies
- Insights across multiple tools (Python, SQL, Excel)

## 🛠 Tools Used
- Python (Pandas, Matplotlib, Seaborn)
- SQL (queries for KPIs)
- Excel (Pivot tables & charts)
- Dataset: movies.csv

## 📊 Key Insights
- Sci-Fi & Action movies generate the highest revenue.
- Higher budgets often lead to higher revenue, but some low-budget films achieve strong ROI.
- Ratings positively correlate with revenue in most genres.

## 📂 Repository Structure
```
movies-data-analysis/
│
├── movies.csv
├── python_analysis.ipynb
├── SQL_Analysis.sql
└── README.md
```

## 🚀 How to Run
1. Clone the repo  
2. Open `movies.csv` in Excel for quick view  
3. Run `python_analysis.ipynb` in Jupyter Notebook  
4. Load `SQL_Analysis.sql` into MySQL/PostgreSQL  
